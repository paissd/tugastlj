<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TOKO FAIZ </title>
</head>
<body>
<h1>SELAMAT DATANG DI TOKO FAIZ</h1>
<table border=1>
<tr>
    OPSI
</tr>
<tr>
    <th>Detail Barang</th>
    <th>
        Penjualan
    </th>
</tr>
<td>
<a href="datatoko/barang/barang.php">Data Barang</a>
</td>
<td>
<a href="datatoko/pembeli/pembeli.php">Data Pembeli</a>
<a href="datatoko/transaksi/transaksi.php">Data transaksi</a>
<a href="datatoko/pembayaran/pembayaran.php">Data Pembayaran</a>
</td>
<tr>
<td>
<a href="datatoko/supplier/supplier.php">Data Supplier</a>
</td>
</tr>
</table>

</body>
</html>