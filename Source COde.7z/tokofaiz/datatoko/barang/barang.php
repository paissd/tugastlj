<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Barang</title>
</head>
<body>
    <!-- menampilkan tabel barang -->
    <h1>Data Penjualan Toko Faiz Desember-Januari</h1>
    <br>
    <h2>Data Barang</h2>
    <a href="tambah.php">+Tambah Data Barang</a>
    <br/>
    <br>
    <a href="cari.php">Cari Barang</a>
    <br>
    <a href="../../index.php">Kembali ke halaman Awal</a>
    <br/>
    <table border="1">
        <tr>
            <th>
                NO
            </th>
            <th>
            Nama Barang			
            </th>
            <th>
            Harga
            </th>
            <th>
            Stok
            </th>
            <th>
                Opsi
            </th>
        </tr>
        <?php
        include 'koneksi.php';
        $no = 1;
        $data = mysqli_query($koneksi,"select * from barang");
        while($d = mysqli_fetch_array($data)){
            ?>
            <tr>
                <td><?php echo $no++; ?></td>
                <td><?php echo $d['nama_barang']; ?></td>
                <td><?php echo $d['harga']; ?></td>
                <td><?php echo $d['stok']; ?></td>
                <td>
                    <a href="edit.php?id=<?php echo $d['id_barang']; ?>">EDIT</a>
                    <a href="hapus.php?id=<?php echo $d['id_barang']; ?>">Hapus</a>
                </td>
            </tr>
            <?php
        }
        ?>
    </table>
</body>
</html>