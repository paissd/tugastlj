<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Data Barang</title>
</head>
<body>
    <h2>Edit Data</h2>
    <br/>
    <a href="barang.php">Kembali Ke halaman awal</a>
    <br/>
    <br/>
    <h3>Silahkan Edit Data Anda </h3>


    <?php
        include 'koneksi.php';
        $id = $_GET['id'];
        $data = mysqli_query($koneksi,"select * from barang where id_barang='$id'");

        while($d = mysqli_fetch_array($data))
        {
            ?> 
            <form method="post" action="update.php">
                <table>
                    <tr>
                        <td>Nama Barang</td>
                        <td>
                            <input type="hidden" name="id" value="<?php echo $d['id_barang']; ?>">
                            <input type="text" name="nama_barang" value="<?php echo $d['nama_barang']; ?>">
                        </td>
                    </tr>
                    <tr>
                        <td>harga</td>
                        <td><input type="text" name="harga" value="<?php echo $d['harga']; ?>"></td>
                    </tr>
                    <tr>
                        <td>Stok</td>
                        <td><input type="text" name="stok" value="<?php echo $d['stok']; ?>"></td>
                    </tr>
                    <tr>
                        <td>ID supplier</td>
                        <td><input type="text" name="id_supplier" value="<?php echo $d['id_supplier']; ?>"></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td><input type="submit" value="SIMPAN"></td>
                    </tr>
                </table>
            </form>
            <?php
        }    
     ?>
</body>
</html>