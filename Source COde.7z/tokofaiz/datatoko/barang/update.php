<?php
include 'koneksi.php';

//menangkap data dari from 
$id = $_POST ['id'];
$nama_barang = $_POST['nama_barang'];
$harga = $_POST['harga'];
$stok = $_POST['stok'];
$id_supplier = $_POST['id_supplier'];

//update ke database
mysqli_query($koneksi,"update barang set nama_barang='$nama_barang', harga='$harga', stok='$stok', id_supplier='$id_supplier' where id_barang=$id");

//mengembalikan ke index
header("location:barang.php");

?>