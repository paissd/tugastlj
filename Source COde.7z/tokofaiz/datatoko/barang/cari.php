<?php
require_once'koneksi.php';
?>

<form method="post">
    <input type="text" name="nt" placeholder="CARI NAMA BARANG">
    <input type="submit" name="submit" value="cari">
</form>
<br>
<br>
<a href="barang.php">Kembali ke halaman utama</a>
<table border="1">
    <tr>
        <td>NO</td>
        <td>Nama barang</td>
        <td>Harga</td>
        <td>Stok</td>
        <td>ID Supplier</td>
    </tr>
<?php
if(!ISSET($_POST['submit'])){
    $no = 1;
    $sql = "SELECT * FROM barang";
    $query = mysqli_query($koneksi, $sql);
    while ($row = mysqli_fetch_array($query)){

        ?>
        <tr>
            <td><?php echo $no++; ?></td>
            <td><?php echo $row['nama_barang']; ?></td>
            <td><?php echo $row['harga']; ?></td>
            <td><?php echo $row['stok']; ?></td>
            <td><?php echo $row['id_supplier']; ?></td>
        </tr>
        <?php
    }
} ?>

<?php if (ISSET($_POST['submit'])){
    $cari = $_POST['nt'];
    $query2 = "SELECT * FROM barang where nama_barang LIKE '%$cari%'";
    $no = 1;

    $sql = mysqli_query($koneksi, $query2);
    while ($r = mysqli_fetch_array($sql)){
        ?>
        <tr>
            <td><?php echo $no++; ?></td>
            <td><?php echo $r['nama_barang']; ?></td>
            <td><?php echo $r['harga']; ?></td>
            <td><?php echo $r['stok']; ?></td>
            <td><?php echo $r['id_supplier']; ?></td>
        </tr>
        <?php
    }
} ?>
</table>