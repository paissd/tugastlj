<?php
include 'koneksi.php';

// menangkap data dari from (tambah.php)
$nama_barang = $_POST['nama_barang'];
$harga = $_POST['harga'];
$stok = $_POST['stok'];
$id_supplier = $_POST['id_supplier'];

// menginput ke database
mysqli_query($koneksi,"insert into barang values('','$nama_barang','$harga','$stok','$id_supplier')");

//mengalihkan halaman tambah ke index
header("location:barang.php");
?>