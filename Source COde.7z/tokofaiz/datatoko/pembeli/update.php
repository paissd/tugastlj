<?php
include 'koneksi.php';

//menangkap data dari from 
$id = $_POST ['id'];
$nama_pembeli = $_POST['nama_pembeli'];
$jk = $_POST['jk'];
$no_telp = $_POST['no_telp'];
$alamat = $_POST['alamat'];

//update ke database
mysqli_query($koneksi,"UPDATE pembeli SET nama_pembeli='$nama_pembeli', jk='$jk', no_telp='$no_telp' , alamat='$alamat' WHERE id_pembeli = '$id'");

//mengembalikan ke index
header("location:pembeli.php");

?>