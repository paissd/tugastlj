<?php
include 'koneksi.php';
 //menangkap data id yang di kirim dari url
 $id = $_GET['id'];

 //menghapus data dari database
 mysqli_query($koneksi,"delete from pembeli where id_pembeli='$id'");

 //mengalihkan ke index
 header("location:pembeli.php");
 ?>