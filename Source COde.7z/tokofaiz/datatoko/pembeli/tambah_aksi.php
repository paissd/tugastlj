<?php
include 'koneksi.php';

// menangkap data dari from (tambah.php)
$nama_pembeli = $_POST['nama_pembeli'];
$jk = $_POST['jk'];
$no_telp = $_POST['no_telp'];
$alamat = $_POST['alamat'];

// menginput ke database
mysqli_query($koneksi,"insert into pembeli values('','$nama_pembeli','$jk','$no_telp','$alamat')");

//mengalihkan halaman tambah ke index
header("location:pembeli.php");
?>