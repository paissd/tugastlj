<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
     <!-- Menampilkan data pembeli -->
     <h2>Data Pembeli</h2>
    <a href="tambah.php">+Tambah Data Pembeli</a>
    <br/>
    <a href="cari.php">Cari nama pembeli</a>
    <br>
    <a href="../../index.php">Kembali ke halaman Awal</a>
    <br/>
    <table border="1">
        <tr>
            <th>
            NO		
            </th>
            <th>
            Nama Pembeli
            </th>
            <th>
            Jenis kelamin
            </th>
            <th>
            No Hp
            </th>
            <th>
                Alamat
            </th>
            <th>
                Opsi
            </th>
        </tr>
        <?php
        include 'koneksi.php';
        $no = 1;
        $data = mysqli_query($koneksi,"select * from pembeli");
        while($d = mysqli_fetch_array($data)){
            ?>
            <tr>
                <td><?php echo $no++; ?></td>
                <td><?php echo $d['nama_pembeli']; ?></td>
                <td><?php echo $d['jk']; ?></td>
                <td><?php echo $d['no_telp']; ?></td>
                <td><?php echo $d['alamat']; ?></td>
                <td>
                    <a href="edit.php?id=<?php echo $d['id_pembeli']; ?>">EDIT</a>
                    <a href="hapus.php?id=<?php echo $d['id_pembeli']; ?>">Hapus</a>
                </td>
            </tr>
            <?php
        }
        ?>
    </table>
</body>
</html>