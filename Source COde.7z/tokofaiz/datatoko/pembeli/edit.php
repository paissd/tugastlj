<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Data pembeli</title>
</head>
<body>
    <h2>Edit Data</h2>
    <br/>
    <a href="pembeli.php">Kembali Ke halaman awal</a>
    <br/>
    <br/>
    <h3>Silahkan Edit Data Anda </h3>

    <?php
        include 'koneksi.php';
        $id = $_GET ['id'];
        $data = mysqli_query($koneksi,"SELECT * FROM pembeli where id_pembeli='$id'");

        while($d = mysqli_fetch_array($data))
        {
            ?> 
            <form method="post" action="update.php">
                <table>
                    <tr>
                        <td>NAMA Pembeli</td>
                        <td>
                            <input type="hidden" name="id" value="<?php echo $d['id_pembeli']; ?>">
                            <input type="text" name="nama_pembeli" value="<?php echo $d['nama_pembeli']; ?>">
                        </td>
                    </tr>
                    <tr>
                        <td>Jenis Kelamin</td>
                        <td><input type="text" name="jk" value="<?php echo $d['jk']; ?>"></td>
                    </tr>
                    <tr>
                        <td>NO Telp</td>
                        <td><input type="number" name="no_telp" value="<?php echo $d['no_telp']; ?>"></td>
                    </tr>
                    <tr>
                        <td>ALAMAT </td>
                        <td><input type="text" name="alamat" value="<?php echo $d['alamat']; ?>"></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td><input type="submit" value="SIMPAN"></td>
                    </tr>
                </table>
            </form>
            <?php
        }    
     ?>
</body>
</html>