<?php
require_once'koneksi.php';
?>

<form method="post">
    <input type="text" name="nt" placeholder="CARI Pembeli">
    <input type="submit" name="submit" value="cari">
</form>
<br>
<br>
<a href="pembeli.php">Kembali ke halaman utama</a>
<table border="1">
    <tr>
        <td>NO</td>
        <td>Nama Pembeli</td>
        <td>Jenis Kelamin</td>
        <td>NO HP</td>
        <td>Alamat</td>
    </tr>
<?php
if(!ISSET($_POST['submit'])){
    $no = 1;
    $sql = "SELECT * FROM pembeli";
    $query = mysqli_query($koneksi, $sql);
    while ($row = mysqli_fetch_array($query)){

        ?>
        <tr>
            <td><?php echo $no++; ?></td>
            <td><?php echo $row['nama_pembeli']; ?></td>
            <td><?php echo $row['jk']; ?></td>
            <td><?php echo $row['no_telp']; ?></td>
            <td><?php echo $row['alamat']; ?></td>
        </tr>
        <?php
    }
} ?>

<?php if (ISSET($_POST['submit'])){
    $cari = $_POST['nt'];
    $query2 = "SELECT * FROM pembeli where nama_pembeli LIKE '%$cari%'";
    $no = 1;

    $sql = mysqli_query($koneksi, $query2);
    while ($r = mysqli_fetch_array($sql)){
        ?>
        <tr>
            <td><?php echo $no++; ?></td>
            <td><?php echo $r['nama_pembeli']; ?></td>
            <td><?php echo $r['jk']; ?></td>
            <td><?php echo $r['no_telp']; ?></td>
            <td><?php echo $r['alamat']; ?></td>
        </tr>
        <?php
    }
} ?>
</table>