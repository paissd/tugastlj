<?php
include 'koneksi.php';

//menangkap data dari from 
$id = $_POST ['id'];
$nama_supplier = $_POST['nama_supplier'];
$no_telp = $_POST['no_telp'];
$alamat = $_POST['alamat'];

//update ke database
mysqli_query($koneksi,"UPDATE supplier SET nama_supplier='$nama_supplier', no_telp='$no_telp' , alamat='$alamat' WHERE id_supplier = '$id'");

//mengembalikan ke index
header("location:supplier.php");

?>