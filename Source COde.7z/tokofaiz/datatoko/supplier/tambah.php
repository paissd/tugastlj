<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Data</title>
</head>
<body>
    
    <h2>Tambah Data Supplier</h2>
    <br/>
    <br/>
    <h3>Silahkan Tambahkan Data Anda</h3>
    <form method="post" action="tambah_aksi.php">
        <table>
            <tr>
                <td>nama_supplier</td>
                <td><input type="text" name="nama_supplier"></td>
            </tr>
            <tr>
                <td>no_telp</td>
                <td><input type="text" name="no_telp"></td>
            </tr>
            <tr>
                <td>alamat</td>
                <td><input type="text" name="alamat"></td>
            
                <td></td>
                <td><input type="submit" value="SIMPAN"></td>
            </tr>
        </table>
    </form>


</body>
</html>