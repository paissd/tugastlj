<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Data SUPPLIER</title>
</head>
<body>
    <h2>Edit Data</h2>
    <br/>
    <a href="supplier.php">Kembali Ke halaman awal</a>
    <br/>
    <br/>
    <h3>Silahkan Edit Data Anda </h3>

    <?php
        include 'koneksi.php';
        $id = $_GET ['id'];
        $data = mysqli_query($koneksi,"SELECT * FROM supplier where id_supplier='$id'");

        while($d = mysqli_fetch_array($data))
        {
            ?> 
            <form method="post" action="update.php">
                <table>
                    <tr>
                        <td>NAMA Supplier</td>
                        <td>
                            <input type="hidden" name="id" value="<?php echo $d['id_supplier']; ?>">
                            <input type="text" name="nama_supplier" value="<?php echo $d['nama_supplier']; ?>">
                        </td>
                    </tr>
                    <tr>
                        <td>NO TELP</td>
                        <td><input type="text" name="no_telp" value="<?php echo $d['no_telp']; ?>"></td>
                    </tr>
                    <tr>
                        <td>ALAMAT </td>
                        <td><input type="text" name="alamat" value="<?php echo $d['alamat']; ?>"></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td><input type="submit" value="SIMPAN"></td>
                    </tr>
                </table>
            </form>
            <?php
        }    
     ?>
</body>
</html>