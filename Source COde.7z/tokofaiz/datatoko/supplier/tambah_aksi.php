<?php
include 'koneksi.php';

// menangkap data dari from (tambah.php)
$nama_supplier = $_POST['nama_supplier'];
$no_telp = $_POST['no_telp'];
$alamat = $_POST['alamat'];

// menginput ke database
mysqli_query($koneksi,"insert into supplier values('','$nama_supplier','$no_telp','$alamat')");

//mengalihkan halaman tambah ke index
header("location:supplier.php");
?>