<?php
include 'koneksi.php';

//menangkap data dari from 
$id = $_POST ['id'];
$id_barang = $_POST['id_barang'];
$id_pembeli = $_POST['id_pembeli'];
$tanggal = $_POST['tanggal'];
$keterangan = $_POST['keterangan'];

//update ke database
mysqli_query($koneksi,"UPDATE transaksi SET id_barang='$id_barang', id_pembeli='$id_pembeli' , tanggal = '$tanggal', keterangan='$keterangan' WHERE id_transaksi = '$id'");

//mengembalikan ke index
header("location:transaksi.php");

?>