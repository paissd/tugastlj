<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Data TRANSAKSI</title>
</head>
<body>
    <h2>Edit Data</h2>
    <br/>
    <a href="transaksi.php">Kembali Ke halaman awal</a>
    <br/>
    <br/>
    <h3>Silahkan Edit Data Anda </h3>

    <?php
        include 'koneksi.php';
        $id = $_GET ['id'];
        $data = mysqli_query($koneksi,"SELECT * FROM transaksi where id_transaksi='$id'");

        while($d = mysqli_fetch_array($data))
        {
            ?> 
            <form method="post" action="update.php">
                <table>
                    <tr>
                        <td>ID PEMBELI</td>
                        <td>
                            <input type="hidden" name="id" value="<?php echo $d['id_transaksi']; ?>">
                            <input type="text" name="id_barang" value="<?php echo $d['id_barang']; ?>">
                        </td>
                    </tr>
                    <tr>
                        <td>ID PEMBELI</td>
                        <td><input type="text" name="id_pembeli" value="<?php echo $d['id_pembeli']; ?>"></td>
                    </tr>
                    <tr>
                        <td>Tanggal</td>
                        <td><input type="date" name="tanggal" value="<?php echo $d['tanggal']; ?>"></td>
                    </tr>
                    <tr>
                        <td>Keterangan</td>
                        <td><input type="text" name="keterangan" value="<?php echo $d['keterangan']; ?>"></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td><input type="submit" value="SIMPAN"></td>
                    </tr>
                </table>
            </form>
            <?php
        }    
     ?>
</body>
</html>