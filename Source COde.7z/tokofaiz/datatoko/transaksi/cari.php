<?php
require_once'koneksi.php';
?>

<form method="post">
    <input type="text" name="nt" placeholder="CARI ID pembeli">
    <input type="submit" name="submit" value="cari">
</form>
<br>
<br>
<a href="transaksi.php">Kembali ke halaman utama</a>
<table border="1">
    <tr>
        <td>NO</td>
        <td>ID Barang</td>
        <td>ID pembeli</td>
        <td>Tanggal</td>
        <td>Keterangan</td>
    </tr>
<?php
if(!ISSET($_POST['submit'])){
    $no = 1;
    $sql = "SELECT * FROM transaksi";
    $query = mysqli_query($koneksi, $sql);
    while ($row = mysqli_fetch_array($query)){

        ?>
        <tr>
            <td><?php echo $no++; ?></td>
            <td><?php echo $row['id_barang']; ?></td>
            <td><?php echo $row['id_pembeli']; ?></td>
            <td><?php echo $row['tanggal']; ?></td>
            <td><?php echo $row['keterangan']; ?></td>
        </tr>
        <?php
    }
} ?>

<?php if (ISSET($_POST['submit'])){
    $cari = $_POST['nt'];
    $query2 = "SELECT * FROM transaksi where id_pembeli LIKE '%$cari%'";
    $no = 1;

    $sql = mysqli_query($koneksi, $query2);
    while ($r = mysqli_fetch_array($sql)){
        ?>
        <tr>
            <td><?php echo $no++; ?></td>
            <td><?php echo $r['id_barang']; ?></td>
            <td><?php echo $r['id_pembeli']; ?></td>
            <td><?php echo $r['tanggal']; ?></td>
            <td><?php echo $r['keterangan']; ?></td>
        </tr>
        <?php
    }
} ?>
</table>