<?php
include 'koneksi.php';

// menangkap data dari from (tambah.php)
$id_barang = $_POST['id_barang'];
$id_pembeli = $_POST['id_pembeli'];
$tanggal = $_POST['tanggal'];
$keterangan = $_POST['keterangan'];

// menginput ke database
mysqli_query($koneksi,"insert into transaksi values('','$id_barang','$id_pembeli','$tanggal','$keterangan')");

//mengalihkan halaman tambah ke index
header("location:transaksi.php");
?>