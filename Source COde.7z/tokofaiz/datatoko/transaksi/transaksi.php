

    <!-- menampilkan data transaksi -->
    <h2>Data Transaksi</h2>
    <a href="tambah.php">+Tambah Data transaksi</a>
    <br/>
    <a href="cari.php">Cari Transaksi</a>
    <br>
    <a href="../../index.php">Kembali ke halaman Awal</a>
    <br/>
    <table border="1">
        <tr>
            <th>
            NO		
            </th>
            <th>
            ID Barang
            </th>
            <th>
            ID Pembeli
            </th>
            <th>
            Tanggal
            </th>
            <th>
                Keterangan
            </th>
            <th>
                Opsi
            </th>
        </tr>
        <?php
        include 'koneksi.php';
        $no = 1;
        $data = mysqli_query($koneksi,"select * from transaksi");
        while($d = mysqli_fetch_array($data)){
            ?>
            <tr>
                <td><?php echo $no++; ?></td>
                <td><?php echo $d['id_barang']; ?></td>
                <td><?php echo $d['id_pembeli']; ?></td>
                <td><?php echo $d['tanggal']; ?></td>
                <td><?php echo $d['keterangan']; ?></td>
                <td>
                    <a href="edit.php?id=<?php echo $d['id_transaksi']; ?>">EDIT</a>
                    <a href="hapus.php?id=<?php echo $d['id_transaksi']; ?>">Hapus</a>
                </td>
            </tr>
            <?php
        }
        ?>
    </table>