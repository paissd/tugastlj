<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Data</title>
</head>
<body>
    
    <h2>Tambah Data Transaksi</h2>
    <br/>
    <br/>
    <h3>Silahkan Tambahkan Data Anda</h3>
    <form method="post" action="tambah_aksi.php">
        <table>
            <tr>
                <td>ID Barang</td>
                <td><input type="text" name="id_barang"></td>
            </tr>
            <tr>
                <td>ID_pembeli</td>
                <td><input type="text" name="id_pembeli"></td>
            </tr>
            <tr>
                <td>Tanggal</td>
                <td><input type="date" name="tanggal"></td>
            <tr>
                <td>Keterangan</td>
                <td><input type="text" name="keterangan"></td>
            </tr>
                <td></td>
                <td><input type="submit" value="SIMPAN"></td>
            </tr>
        </table>
    </form>


</body>
</html>