<?php
include 'koneksi.php';

//menangkap data dari from 
$id = $_POST ['id'];
$tgl_bayar = $_POST['tgl_bayar'];
$total_bayar = $_POST['total_bayar'];
$id_transaksi = $_POST['id_transaksi'];

//update ke database
mysqli_query($koneksi,"UPDATE pembayaran SET tgl_bayar='$tgl_bayar', total_bayar='$total_bayar', id_transaksi='$id_transaksi' WHERE id_pembayaran = '$id'");

//mengembalikan ke index
header("location:pembayaran.php");

?>