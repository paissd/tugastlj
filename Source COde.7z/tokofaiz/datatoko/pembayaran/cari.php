<?php
require_once'koneksi.php';
?>

<form method="post">
    <input type="text" name="nt" placeholder="CARI PEMBAYRAN">
    <input type="submit" name="submit" value="cari">
</form>
<br>
<br>
<a href="pembayaran.php">Kembali ke halaman utama</a>
<table border="1">
    <tr>
        <td>NO</td>
        <td>Tanggal Pembayaran</td>
        <td>Total Bayar</td>
        <td>ID transaksi</td>
    </tr>
<?php
if(!ISSET($_POST['submit'])){
    $no = 1;
    $sql = "SELECT * FROM pembayaran";
    $query = mysqli_query($koneksi, $sql);
    while ($row = mysqli_fetch_array($query)){

        ?>
        <tr>
            <td><?php echo $no++; ?></td>
            <td><?php echo $row['tgl_bayar']; ?></td>
            <td><?php echo $row['total_bayar']; ?></td>
            <td><?php echo $row['id_transaksi']; ?></td>
        </tr>
        <?php
    }
} ?>

<?php if (ISSET($_POST['submit'])){
    $cari = $_POST['nt'];
    $query2 = "SELECT * FROM pembayaran where tgl_bayar LIKE '%$cari%'";
    $no = 1;

    $sql = mysqli_query($koneksi, $query2);
    while ($r = mysqli_fetch_array($sql)){
        ?>
        <tr>
            <td><?php echo $no++; ?></td>
            <td><?php echo $r['tgl_bayar']; ?></td>
            <td><?php echo $r['total_bayar']; ?></td>
            <td><?php echo $r['id_transaksi']; ?></td>
        </tr>
        <?php
    }
} ?>
</table>