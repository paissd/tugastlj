<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Data Pembayaran</title>
</head>
<body>
    <h2>Edit Data</h2>
    <br/>
    <a href="pembayaran.php">Kembali Ke halaman awal</a>
    <br/>
    <br/>
    <h3>Silahkan Edit Data Anda </h3>

    <?php
        include 'koneksi.php';
        $id = $_GET ['id'];
        $data = mysqli_query($koneksi,"SELECT * FROM pembayaran where id_pembayaran='$id'");

        while($d = mysqli_fetch_array($data))
        {
            ?> 
            <form method="post" action="update.php">
                <table>
                    <tr>
                        <td>Tanggal Pembayaran</td>
                        <td>
                            <input type="hidden" name="id" value="<?php echo $d['id_pembayaran']; ?>">
                            <input type="date" name="tgl_bayar" value="<?php echo $d['tgl_bayar']; ?>">
                        </td>
                    </tr>
                    <tr>
                        <td>Total Bayar</td>
                        <td><input type="number" name="total_bayar" value="<?php echo $d['total_bayar']; ?>"></td>
                    </tr>
                    <tr>
                        <td>ID Transaksi</td>
                        <td><input type="number" name="id_transaksi" value="<?php echo $d['id_transaksi']; ?>"></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td><input type="submit" value="SIMPAN"></td>
                    </tr>
                </table>
            </form>
            <?php
        }    
     ?>
</body>
</html>