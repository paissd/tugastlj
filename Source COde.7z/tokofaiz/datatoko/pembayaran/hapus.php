<?php
include 'koneksi.php';
 //menangkap data id yang di kirim dari url
 $id = $_GET['id'];

 //menghapus data dari database
 mysqli_query($koneksi,"delete from pembayaran where id_pembayaran='$id'");

 //mengalihkan ke index
 header("location:pembayaran.php");
 ?>