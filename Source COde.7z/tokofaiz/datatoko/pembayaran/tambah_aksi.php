<?php
include 'koneksi.php';

// menangkap data dari from (tambah.php)
$tgl_bayar = $_POST['tgl_bayar'];
$total_bayar = $_POST['total_bayar'];
$id_transaksi = $_POST['id_transaksi'];

// menginput ke database
mysqli_query($koneksi,"insert into pembayaran values('','$tgl_bayar','$total_bayar','$id_transaksi')");

//mengalihkan halaman tambah ke index
header("location:pembayaran.php");
?>